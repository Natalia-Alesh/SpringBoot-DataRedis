package com.javatechie.redis.queue;

public interface MessagePublisher {

    void publish(final String message);
}